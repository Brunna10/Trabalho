package br.edu.univas.view;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.ScrollPane;
import java.awt.ScrollPaneAdjustable;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;


public class Trabalho1 extends JFrame {



	private JTextField nameText;
	
	
				public Trabalho1(){
				this.setTitle("Cadastro de Livros");
				this.setSize(600,400);
				this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				this.setLocationRelativeTo(null);
				this.setLayout(new FlowLayout());
				initialize ();
			}
				
				private void initialize (){
					JLabel nameLabel =new JLabel();
					nameLabel.setText("Título");
					this.getContentPane().add(nameLabel);	
					
					nameText = new JTextField();
					nameText.setColumns(80);
					this.getContentPane().add(nameText);
					
					JLabel nameLabel1 =new JLabel();
					nameLabel1.setText("Autor");
					this.getContentPane().add(nameLabel1);	
					
					nameText = new JTextField();
					nameText.setColumns(100);
					this.getContentPane().add(nameText);
					
					JLabel nameLabel2 =new JLabel();
					nameLabel2.setText("Valor");
					this.getContentPane().add(nameLabel2);	
					
					nameText = new JTextField();
					nameText.setColumns(100);
					this.getContentPane().add(nameText);
				
					
				JButton button = new JButton();
				button.setText("Salvar");
				button.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						System.out.println(nameText.getText());
					}
				});
				this.getContentPane().add(button);
	
				String[] columnNames = 
					{"Título", "Autor", "Valor"
				};
				
				Object [] [] tableData ={
						{"b","",""},
						{"b","",""},
						{"b","c",""},
				};
						
				JTable table = new JTable(tableData, columnNames);
				
				JScrollPane scrollTable = new JScrollPane(table);
				scrollTable.setPreferredSize(new Dimension(700,100));
				scrollTable.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
				scrollTable.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
				
				this.getContentPane().add(scrollTable);
				
	
				}
}

						
				
			
	
				
				
	



package br.edu.univas.view;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.ScrollPane;
import java.awt.ScrollPaneAdjustable;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;


public class Trabalho1 extends JFrame {

	private JTextField tituloText;
	private JTextField autorText;
	private JTextField valorText;
	private JTable table;
	
	
				public Trabalho1(){
				this.setTitle("Cadastro de Livros");
				this.setSize(600,400);
				this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				this.setLocationRelativeTo(null);
				this.setLayout(new FlowLayout());
				initialize ();
			}
				
				private void initialize (){
					JLabel nameLabel =new JLabel();
					nameLabel.setText("Título");
					this.getContentPane().add(nameLabel);	
					
					tituloText = new JTextField();
					tituloText.setColumns(40);
					this.getContentPane().add(tituloText);
					
					JLabel nameLabel1 =new JLabel();
					nameLabel1.setText("Autor");
					this.getContentPane().add(nameLabel1);	
					
					autorText = new JTextField();
					autorText.setColumns(40);
					this.getContentPane().add(autorText);
					
					JLabel nameLabel2 =new JLabel();
					nameLabel2.setText("Valor");
					this.getContentPane().add(nameLabel2);	
					
					valorText = new JTextField();
					valorText.setColumns(100);
					this.getContentPane().add(valorText);
				
					
				JButton button = new JButton();
				button.setText("Salvar");
				button.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
					System.out.println(tituloText.getText());
					System.out.println(autorText.getText());
					System.out.println(valorText.getText());
					
					Object[]row ={
							tituloText.getText(),
							autorText.getText(),
							valorText.getText()
					};
					
					DefaultTableModel model = (DefaultTableModel)table.getModel();
					model.addRow(row);
					}
					});
				this.getContentPane().add(button);
				
				JLabel nameLabel3 = new JLabel();
				nameLabel3.setText("Livros Cadastrados");
				this.getContentPane().add(nameLabel3);
				
				
				String[] columnNames = 
					{"Título", "Autor", "Valor"
				};
				
				Object [][] tableData = new Object[0][];
				;
						
				table= new JTable(new DefaultTableModel(tableData, columnNames));
				
				JScrollPane scrollTable = new JScrollPane(table);
				scrollTable.setPreferredSize(new Dimension(700,100));
				scrollTable.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
				scrollTable.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
				
				this.getContentPane().add(scrollTable);
				
	
				}
}

						
				
			
	
				
				
	



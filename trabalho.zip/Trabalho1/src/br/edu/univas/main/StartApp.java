package br.edu.univas.main;

import javax.swing.JLabel;

import br.edu.univas.view.Trabalho1;

public class StartApp {
	
		public static void main(String[] args) {
			Trabalho1 tela = new Trabalho1();
			tela.setVisible(true);
		}
		


}
